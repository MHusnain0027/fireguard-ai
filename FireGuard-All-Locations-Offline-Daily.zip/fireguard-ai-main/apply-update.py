"""Apply only this update, commit its files and push the current Git branch."""
import hashlib
import os
from pathlib import Path
import subprocess
import zipfile

ARCHIVE = "FireGuard-All-Locations-Offline-Daily.zip"
BASELINE = {'app/api/locations/route.ts': '54fbb77cb58f247f9efae883bbeec1ca1c0cc37661d63b266efc86d2d35135ed', 'app/page.tsx': '08529368ab65c040e2c46ccf61be85e4844320052f6104b245f62c141e1ff66d', 'public/sw.js': 'f6e7c0ce5ee995ac4d8742b8e7c684d08e362aa7a52777f400295bebb855eaf8', 'app/api/keep-alive/route.ts': None, 'vercel.json': None, 'LOCATION-UPDATE.md': None}

def git(*args, capture=False):
    return subprocess.run(["git", *args], check=True, text=True,
                          stdout=subprocess.PIPE if capture else None).stdout

repo = Path(git("rev-parse", "--show-toplevel", capture=True).strip())
archive = Path(ARCHIVE).resolve()
os.chdir(repo)
if git("diff", "--cached", "--name-only", capture=True).strip():
    raise SystemExit("STOP: Other files are already staged. Commit or unstage them first, then retry.")
branch = git("branch", "--show-current", capture=True).strip()
if not branch:
    raise SystemExit("STOP: Check out your intended branch before applying the update.")
git("remote", "get-url", "origin", capture=True)
app = repo / "fireguard-ai-app"
if not (app / "package.json").is_file():
    app = repo
if not (app / "app/page.tsx").is_file():
    raise SystemExit("STOP: Run from the FireGuard Git repository.")
updates = []
with zipfile.ZipFile(archive) as bundle:
    for relative, original_hash in BASELINE.items():
        target = app / relative
        if target.is_symlink() or any(p.is_symlink() for p in target.parents if p != repo.parent):
            raise SystemExit(f"STOP: Refusing symlink path: {relative}")
        content = bundle.read("fireguard-ai-main/fireguard-ai-app/" + relative)
        if target.exists():
            current = target.read_bytes()
            if current != content and hashlib.sha256(current).hexdigest() != original_hash:
                raise SystemExit(f"STOP: {relative} has different edits. Merge that file before retrying.")
        elif original_hash is not None:
            raise SystemExit(f"STOP: Expected file is missing: {relative}")
        updates.append((target, content))
# All paths have been checked before any source file changes.
for target, content in updates:
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(content)
paths = [str(target.relative_to(repo)) for target, _ in updates]
git("add", "--", *paths)
if git("diff", "--cached", "--name-only", capture=True).strip():
    git("commit", "-m", "Fix all locations loading, complete offline sync and daily database activity")
else:
    print("Update already applied; nothing new to commit.")
git("push", "-u", "origin", branch)
print("Done: location update committed and pushed. Complete the one-time Vercel CRON_SECRET setup in LOCATION-UPDATE.md.")
